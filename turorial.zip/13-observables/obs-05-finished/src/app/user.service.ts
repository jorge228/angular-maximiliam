import { Injectable } from "@angular/core";
import { Subject } from "rxjs";

@Injectable({ providedIn: "root" })
export class UserService {
  // como un eventEmitter
  activatedEmitter = new Subject<boolean>();
}
